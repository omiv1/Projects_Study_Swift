// The Swift Programming Language
// https://docs.swift.org/swift-book

func k1() {
    let tenisista1 = Tenisista(imie: "Roger", nazwisko: "Federer", waga: 85.0, wzrost: 185.0, pesel: "01010112345", obywatelstwo: .inne, rodzajGry: .single, najwyzszaPozycja: 1, sumarycznaLiczbaPunktow: 2000, obecnaPozycja: 1, ostatnieTurnieje: [])
    let tenisista2 = Tenisista(imie: "Rafael", nazwisko: "Nadal", waga: 85.0, wzrost: 185.0, pesel: "02020223456", obywatelstwo: .inne, rodzajGry: .single, najwyzszaPozycja: 2, sumarycznaLiczbaPunktow: 1500, obecnaPozycja: 2, ostatnieTurnieje: [])
    let tenisista3 = Tenisista(imie: "Novak", nazwisko: "Djokovic", waga: 77.0, wzrost: 188.0, pesel: "03030334567", obywatelstwo: .inne, rodzajGry: .single, najwyzszaPozycja: 3, sumarycznaLiczbaPunktow: 1200, obecnaPozycja: 3, ostatnieTurnieje: [])

    var ranking = RankingTenisistow(tenisisci: [tenisista1, tenisista2, tenisista3])

// Wyświetlenie danych tenisistów
    ranking.wyswietlDaneTenisistow()

// Dodanie wyników turnieju
    let nazwaTurnieju = "US Open 2023"
    let uczestnicy = ["01010112345", "02020223456", "03030334567"]
    let punkty = [100, 80, 60]

    ranking.uaktualnijWynikiTurnieju(nazwaTurnieju: nazwaTurnieju, uczestnicy: uczestnicy, punkty: punkty)

// Wyświetlenie zaktualizowanych danych tenisistów
    ranking.wyswietlDaneTenisistow()
}

// Utworzenie kilku obiektów Zwierze
let zwierze1 = Zwierze(imie: "Fiona", waga: 50.0, wzrost: 120.0, rokUrodzenia: 2015, numerIdentyfikacyjny: "ID123", typ: .kręgowce, gromada: .ssaki, liczbaKończyn: 4, iloscWymaganegoPozywieniaDziennie: 2.0, wymaganaMinimalnaPowierzchniaDoZycia: 15.0, karmienie: [(1.5, "8:00"), (0.5, "14:00")])

let zwierze2 = Zwierze(imie: "Charlie", waga: 10.0, wzrost: 50.0, rokUrodzenia: 2020, numerIdentyfikacyjny: "ID456", typ: .kręgowce, gromada: .ptaki, liczbaKończyn: 2, iloscWymaganegoPozywieniaDziennie: 0.5, wymaganaMinimalnaPowierzchniaDoZycia: 5.0, karmienie: [(0.2, "9:00"), (0.3, "16:00")])

// Wyświetlenie danych zwierząt
zwierze1.wyswietlDane()
print("-----------------------------")
zwierze2.wyswietlDane()
// Tworzenie zoo składającego się z 3 obiektów klasy Zwierze
let zoo = Zoo(zwierzeta: [
    Zwierze(imie: "Simba", waga: 150.0, wzrost: 120.0, rokUrodzenia: 2010, numerIdentyfikacyjny: "ID001", typ: .kręgowce, gromada: .ssaki, liczbaKończyn: 4, iloscWymaganegoPozywieniaDziennie: 5.0, wymaganaMinimalnaPowierzchniaDoZycia: 30.0, karmienie: [(2.0, "9:00"), (3.0, "15:00")]),
    Zwierze(imie: "Tweety", waga: 0.2, wzrost: 10.0, rokUrodzenia: 2022, numerIdentyfikacyjny: "ID002", typ: .kręgowce, gromada: .ptaki, liczbaKończyn: 2, iloscWymaganegoPozywieniaDziennie: 0.1, wymaganaMinimalnaPowierzchniaDoZycia: 2.0, karmienie: [(0.05, "8:00"), (0.05, "12:00")]),
    Zwierze(imie: "Rex", waga: 25.0, wzrost: 60.0, rokUrodzenia: 2015, numerIdentyfikacyjny: "ID003", typ: .kręgowce, gromada: .ssaki, liczbaKończyn: 4, iloscWymaganegoPozywieniaDziennie: 2.5, wymaganaMinimalnaPowierzchniaDoZycia: 15.0, karmienie: [(1.5, "10:00"), (2.0, "18:00")])
])

// Wyświetlanie danych wszystkich zwierząt w zoo
print("Dane wszystkich zwierząt w zoo:")
zoo.wyswietlDaneZwierzat()

// Uaktualnianie danych dotyczących karmienia
let aktualizacjeKarmienia = [
    ("ID001", "9:00", 1.8),
    ("ID002", "12:00", 0.15),
    ("ID003", "18:00", 2.8)
]

print("\nUaktualnienie danych dotyczących karmienia:")
zoo.uaktualnijIlosciPozywienia(identyfikatory: aktualizacjeKarmienia.map { $0.0 }, godzinaKarmienia: aktualizacjeKarmienia.first?.1 ?? "", nowaIloscPokarmu: aktualizacjeKarmienia.first?.2 ?? 0.0)

// Wyświetlanie danych wszystkich zwierząt po aktualizacji
print("\nDane wszystkich zwierząt po aktualizacji:")
zoo.wyswietlDaneZwierzat()
