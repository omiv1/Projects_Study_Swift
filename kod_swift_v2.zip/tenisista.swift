class Tenisista: Osoba {
    enum RodzajGry {
        case single, double, singleAndDouble
    }

    var rodzajGry: RodzajGry
    var najwyzszaPozycja: Int
    var sumarycznaLiczbaPunktow: Int
    var obecnaPozycja: Int
    var ostatnieTurnieje: [(nazwa: String, punkty: Int)]

    init(imie: String, nazwisko: String, waga: Double, wzrost: Double, pesel: String, obywatelstwo: Obywatelstwo,
         rodzajGry: RodzajGry, najwyzszaPozycja: Int, sumarycznaLiczbaPunktow: Int, obecnaPozycja: Int, ostatnieTurnieje: [(nazwa: String, punkty: Int)]) {

        self.rodzajGry = rodzajGry
        self.najwyzszaPozycja = najwyzszaPozycja
        self.sumarycznaLiczbaPunktow = sumarycznaLiczbaPunktow
        self.obecnaPozycja = obecnaPozycja
        self.ostatnieTurnieje = ostatnieTurnieje

        super.init(imie: imie, nazwisko: nazwisko, waga: waga, wzrost: wzrost, pesel: pesel, obywatelstwo: obywatelstwo)
    }

    override func wyswietlDane() {
        super.wyswietlDane()
        print("Rodzaj gry: \(rodzajGry)")
        print("Najwyższa pozycja: \(najwyzszaPozycja)")
        print("Sumaryczna liczba punktów: \(sumarycznaLiczbaPunktow)")
        print("Obecna pozycja: \(obecnaPozycja)")
        print("Ostatnie turnieje:")
        for turniej in ostatnieTurnieje {
            print("- \(turniej.nazwa): \(turniej.punkty) punktów")
        }
    }

    func dodajTurniej(nazwa: String, punkty: Int) {
        let nowyTurniej = (nazwa: nazwa, punkty: punkty)
        ostatnieTurnieje.append(nowyTurniej)
    }
}
