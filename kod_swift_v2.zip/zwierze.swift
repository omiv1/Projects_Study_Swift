class Zwierze: TypZwierzecia {
    enum Gromada: String {
        case ptaki, ssaki, gady
        // Dodaj inne gromady według potrzeb
    }

    var gromada: Gromada
    var liczbaKończyn: Int
    var iloscWymaganegoPozywieniaDziennie: Double
    var wymaganaMinimalnaPowierzchniaDoZycia: Double
    var karmienie: [(iloscPokarmu: Double, godzinaKarmienia: String)]

    init(imie: String, waga: Double, wzrost: Double, rokUrodzenia: Int, numerIdentyfikacyjny: String, typ: Typ,
         gromada: Gromada, liczbaKończyn: Int, iloscWymaganegoPozywieniaDziennie: Double, wymaganaMinimalnaPowierzchniaDoZycia: Double, karmienie: [(iloscPokarmu: Double, godzinaKarmienia: String)]) {

        self.gromada = gromada
        self.liczbaKończyn = liczbaKończyn
        self.iloscWymaganegoPozywieniaDziennie = iloscWymaganegoPozywieniaDziennie
        self.wymaganaMinimalnaPowierzchniaDoZycia = wymaganaMinimalnaPowierzchniaDoZycia
        self.karmienie = karmienie

        super.init(imie: imie, waga: waga, wzrost: wzrost, rokUrodzenia: rokUrodzenia, numerIdentyfikacyjny: numerIdentyfikacyjny, typ: typ)
    }

    override func wyswietlDane() {
        super.wyswietlDane()
        print("Gromada: \(gromada.rawValue)")
        print("Liczba kończyn: \(liczbaKończyn)")
        print("Ilość wymaganego pożywienia dziennie: \(iloscWymaganegoPozywieniaDziennie) kg")
        print("Wymagana minimalna powierzchnia do życia: \(wymaganaMinimalnaPowierzchniaDoZycia) m²")
        print("Karmienie:")
        for karmienieInfo in karmienie {
            print("- \(karmienieInfo.iloscPokarmu) kg o godzinie \(karmienieInfo.godzinaKarmienia)")
        }
    }

    // Funkcja do aktualizacji ilości pokarmu dla podanej godziny karmienia
    func aktualizujIloscPokarmu(godzinaKarmienia: String, nowaIloscPokarmu: Double) {
        if let index = karmienie.firstIndex(where: { $0.godzinaKarmienia == godzinaKarmienia }) {
            karmienie[index].iloscPokarmu = nowaIloscPokarmu
        }
    }
}
