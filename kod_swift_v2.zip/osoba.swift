import Foundation

enum Obywatelstwo: String {
    case polskie, inne
}

class Osoba {
    var imie: String
    var nazwisko: String
    var waga: Double
    var wzrost: Double
    var pesel: String
    var obywatelstwo: Obywatelstwo

    init(imie: String, nazwisko: String, waga: Double, wzrost: Double, pesel: String, obywatelstwo: Obywatelstwo) {
        self.imie = imie
        self.nazwisko = nazwisko
        self.waga = waga
        self.wzrost = wzrost
        self.pesel = pesel
        self.obywatelstwo = obywatelstwo
    }

    func obliczWiek(dataUrodzenia: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.year], from: dataUrodzenia, to: currentDate)
        return ageComponents.year!
    }

    func wyswietlDane() {
        print("Imię: \(imie)")
        print("Nazwisko: \(nazwisko)")
        print("Waga: \(waga) kg")
        print("Wzrost: \(wzrost) cm")
        print("PESEL: \(pesel)")
        print("Obywatelstwo: \(obywatelstwo.rawValue)")
    }
}
