import Foundation

class Zoo {
    var zwierzeta: [Zwierze]

    init(zwierzeta: [Zwierze]) {
        self.zwierzeta = zwierzeta
    }

    // Funkcja inicjująca dane wszystkich zwierząt
    func inicjujDaneZwierzat() {
        // Możesz dodać kod inicjalizujący dane zwierząt
    }

    // Funkcja wyświetlająca wszystkie dane zwierząt
    func wyswietlDaneZwierzat() {
        for zwierze in zwierzeta {
            zwierze.wyswietlDane()
            print("-----------------------------")
        }
    }

    // Funkcja wyświetlająca wszystkie zwierzęta bezkręgowe
    func wyswietlBezkręgoweZwierzeta() {
        let bezkregowce = zwierzeta.filter { $0.typ == .bezkręgowce }
        for zwierze in bezkregowce {
            zwierze.wyswietlDane()
            print("-----------------------------")
        }
    }

    // Funkcja wyświetlająca wszystkie najmłodsze zwierzęta
    func wyswietlNajmlodszeZwierzeta() {
        let najmlodszeZwierzeta = zwierzeta.sorted { $0.rokUrodzenia < $1.rokUrodzenia }
        for zwierze in najmlodszeZwierzeta {
            zwierze.wyswietlDane()
            print("-----------------------------")
        }
    }

    // Funkcja zwracająca obiekt klasy Zwierze na podstawie podanego identyfikatora
    func znajdzZwierze(identyfikator: String) -> Zwierze? {
        return zwierzeta.first { $0.numerIdentyfikacyjny == identyfikator }
    }

    // Funkcja wyświetlająca wszystkie zwierzęta, których pora karmienia będzie w ciągu najbliższych dwóch godzin
    func wyswietlZwierzetaDoKarmienia(aktualnaGodzina: String) {
        let dzisiaj = Calendar.current.component(.day, from: Date())

        for zwierze in zwierzeta {
            for karmienieInfo in zwierze.karmienie {
                let godzinaKarmieniaComponents = karmienieInfo.godzinaKarmienia.components(separatedBy: ":")
                if let godzina = Int(godzinaKarmieniaComponents.first ?? ""), let minuta = Int(godzinaKarmieniaComponents.last ?? "") {
                    let karmienieDate = Calendar.current.date(bySettingHour: godzina, minute: minuta, second: 0, of: Date())

                    if let karmienieDate = karmienieDate, karmienieDate > Date() && Calendar.current.component(.day, from: karmienieDate) == dzisiaj {
                        // Wyświetlenie zwierzęcia, którego karmienie jest w ciągu najbliższych dwóch godzin
                        zwierze.wyswietlDane()
                        print("-----------------------------")
                        break
                    }
                }
            }
        }
    }

    // Funkcja uaktualniająca ilości pożywienia dla zwierząt o podanych identyfikatorach oraz porze karmienia
    func uaktualnijIlosciPozywienia(identyfikatory: [String], godzinaKarmienia: String, nowaIloscPokarmu: Double) {
        for identyfikator in identyfikatory {
            if let zwierze = znajdzZwierze(identyfikator: identyfikator) {
                zwierze.aktualizujIloscPokarmu(godzinaKarmienia: godzinaKarmienia, nowaIloscPokarmu: nowaIloscPokarmu)
            }
        }
    }
}
