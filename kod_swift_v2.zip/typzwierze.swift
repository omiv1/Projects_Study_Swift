import Foundation

enum Typ: String {
    case kręgowce, bezkręgowce
}

class TypZwierzecia {
    var imie: String
    var waga: Double
    var wzrost: Double
    var rokUrodzenia: Int
    var numerIdentyfikacyjny: String
    var typ: Typ

    init(imie: String, waga: Double, wzrost: Double, rokUrodzenia: Int, numerIdentyfikacyjny: String, typ: Typ) {
        self.imie = imie
        self.waga = waga
        self.wzrost = wzrost
        self.rokUrodzenia = rokUrodzenia
        self.numerIdentyfikacyjny = numerIdentyfikacyjny
        self.typ = typ
    }

    func obliczWiek(aktualnyRok: Int) -> Int {
        return aktualnyRok - rokUrodzenia
    }

    func wyswietlDane() {
        print("Imię: \(imie)")
        print("Waga: \(waga) kg")
        print("Wzrost: \(wzrost) cm")
        print("Rok urodzenia: \(rokUrodzenia)")
        print("Numer identyfikacyjny: \(numerIdentyfikacyjny)")
        print("Typ: \(typ.rawValue)")
    }
}
