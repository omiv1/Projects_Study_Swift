//import Foundation
//
//// Typ wyliczeniowy dla obywatelstwa
//enum Obywatelstwo {
//    case polskie, zagraniczne1, zagraniczne2
//}
//
//// Klasa Osoba
//class Osoba {
//    var imie: String
//    var nazwisko: String
//    var waga: Double
//    var wzrost: Double
//    var pesel: String
//    var obywatelstwo: Obywatelstwo
//
//    init(imie: String, nazwisko: String, waga: Double, wzrost: Double, pesel: String, obywatelstwo: Obywatelstwo) {
//        self.imie = imie
//        self.nazwisko = nazwisko
//        self.waga = waga
//        self.wzrost = wzrost
//        self.pesel = pesel
//        self.obywatelstwo = obywatelstwo
//    }
//
//    func obliczWiekNaPodstawiePeselu(dataUrodzenia: Date) -> Int {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "yyyy/MM/dd"
//        guard let date = formatter.date(from: "2000/01/01") else {
//            return 0
//        }
//        let ageComponents = Calendar.current.dateComponents([.year], from: date, to: dataUrodzenia)
//        return ageComponents.year ?? 0
//    }
//
//    func wyswietlDane() {
//        print("Imię: \(imie)")
//        print("Nazwisko: \(nazwisko)")
//        print("Waga: \(waga) kg")
//        print("Wzrost: \(wzrost) cm")
//        print("PESEL: \(pesel)")
//        print("Obywatelstwo: \(obywatelstwo)")
//    }
//}
//
//// Klasa Tenisista dziedzicząca po klasie Osoba
//class Tenisista: Osoba {
//    var rodzajGry: String
//    var najwyzszaPozycja: Int
//    var sumarycznaLiczbaPunktow: Int
//    var obecnaPozycja: Int
//    var ostatnieTurnieje: [(nazwa: String, punkty: Int)]
//
//    init(imie: String, nazwisko: String, waga: Double, wzrost: Double, pesel: String, obywatelstwo: Obywatelstwo,
//         rodzajGry: String, najwyzszaPozycja: Int, sumarycznaLiczbaPunktow: Int, obecnaPozycja: Int,
//         ostatnieTurnieje: [(nazwa: String, punkty: Int)]) {
//        self.rodzajGry = rodzajGry
//        self.najwyzszaPozycja = najwyzszaPozycja
//        self.sumarycznaLiczbaPunktow = sumarycznaLiczbaPunktow
//        self.obecnaPozycja = obecnaPozycja
//        self.ostatnieTurnieje = ostatnieTurnieje
//        super.init(imie: imie, nazwisko: nazwisko, waga: waga, wzrost: wzrost, pesel: pesel, obywatelstwo: obywatelstwo)
//    }
//
//    override func wyswietlDane() {
//        super.wyswietlDane()
//        print("Rodzaj gry: \(rodzajGry)")
//        print("Najwyższa pozycja: \(najwyzszaPozycja)")
//        print("Sumaryczna liczba punktów: \(sumarycznaLiczbaPunktow)")
//        print("Obecna pozycja: \(obecnaPozycja)")
//        print("Ostatnie turnieje:")
//        for turniej in ostatnieTurnieje {
//            print("- \(turniej.nazwa): \(turniej.punkty) punktów")
//        }
//    }
//}
//func tenis() {
//// Przykładowe użycie
//    let dataUrodzeniaFormatter = DateFormatter()
//    dataUrodzeniaFormatter.dateFormat = "yyyy/MM/dd"
//    let dataUrodzenia = dataUrodzeniaFormatter.date(from: "2000/01/15")
//
//    let ostatnieTurnieje = [("Australian Open", 80), ("French Open", 90), ("Wimbledon", 95)]
//
//    let tenisista = Tenisista(imie: "Novak", nazwisko: "Djokovic", waga: 80, wzrost: 188, pesel: "00011512345", obywatelstwo: .zagraniczne1,
//            rodzajGry: "single", najwyzszaPozycja: 1, sumarycznaLiczbaPunktow: 10000, obecnaPozycja: 2,
//            ostatnieTurnieje: ostatnieTurnieje)
//
//    tenisista.wyswietlDane()
//}
//
//class RankingTenisistow {
//    var tenisisci: [Tenisista] = []
//
//    init(tenisisci: [Tenisista]) {
//        self.tenisisci = tenisisci
//    }
//    func inicjujDaneTenisistow() {
//        let tenisista1 = Tenisista(imie: "Novak", nazwisko: "Djokovic", waga: 80, wzrost: 188, pesel: "00011512345", obywatelstwo: .zagraniczne1,
//                rodzajGry: "single", najwyzszaPozycja: 1, sumarycznaLiczbaPunktow: 10000, obecnaPozycja: 2,
//                ostatnieTurnieje: [("Australian Open", 80), ("French Open", 90), ("Wimbledon", 95)])
//        let tenisista2 = Tenisista(imie: "Rafael", nazwisko: "Nadal", waga: 85, wzrost: 185, pesel: "11122233344", obywatelstwo: .zagraniczne2,
//                rodzajGry: "single", najwyzszaPozycja: 2, sumarycznaLiczbaPunktow: 9500, obecnaPozycja: 3,
//                ostatnieTurnieje: [("Australian Open", 85), ("French Open", 95), ("US Open", 90)])
//        let tenisista3 = Tenisista(imie: "Roger", nazwisko: "Federer", waga: 75, wzrost: 187, pesel: "99988877766", obywatelstwo: .polskie,
//                rodzajGry: "single", najwyzszaPozycja: 3, sumarycznaLiczbaPunktow: 9000, obecnaPozycja: 1,
//                ostatnieTurnieje: [("Wimbledon", 100), ("US Open", 80), ("Australian Open", 95)])
//
//        tenisisci = [tenisista1, tenisista2, tenisista3]
//    }
//
//    func wyswietlDaneTenisistow() {
//        for tenisista in tenisisci {
//            tenisista.wyswietlDane()
//            print("-------------------------------")
//        }
//    }
//
//    func wyswietlSinglistow() {
//        let singlistowie = tenisisci.filter { $0.rodzajGry.lowercased() == "single" }
//        for singlista in singlistowie {
//            singlista.wyswietlDane()
//            print("-------------------------------")
//        }
//    }
//
//    func wyswietlTenisistowONajwyzszejPozycji() {
//        let posortowaniTenisisci = tenisisci.sorted { $0.najwyzszaPozycja < $1.najwyzszaPozycja }
//        for tenisista in posortowaniTenisisci {
//            tenisista.wyswietlDane()
//            print("-------------------------------")
//        }
//    }
//
//    func znajdzTenisistePoPeselu(pesel: String) -> Tenisista? {
//        return tenisisci.first { $0.pesel == pesel }
//    }
//
//    func uaktualnijTenisiste(pesel: String, nazwaTurnieju: String, punkty: Int) {
//        if let tenisista = znajdzTenisistePoPeselu(pesel: pesel) {
//            tenisista.ostatnieTurnieje.append((nazwa: nazwaTurnieju, punkty: punkty))
//            uaktualnijPozycje(tenisista: tenisista)
//        }
//    }
//
//    func uaktualnijWynikiTurnieju(nazwaTurnieju: String, wyniki: [(pesel: String, punkty: Int)]) {
//        for wynik in wyniki {
//            if let tenisista = znajdzTenisistePoPeselu(pesel: wynik.pesel) {
//                tenisista.ostatnieTurnieje.append((nazwa: nazwaTurnieju, punkty: wynik.punkty))
//                uaktualnijPozycje(tenisista: tenisista)
//            }
//        }
//    }
//
//    private func uaktualnijPozycje(tenisista: Tenisista) {
//        let punkty = tenisista.sumarycznaLiczbaPunktow
//        if punkty >= 1500 {
//            tenisista.obecnaPozycja = 1
//        } else if punkty >= 1000 {
//            tenisista.obecnaPozycja = 2
//        } else if punkty >= 500 {
//            tenisista.obecnaPozycja = 3
//        } else if punkty >= 400 {
//            tenisista.obecnaPozycja = 4
//        } else if punkty >= 300 {
//            tenisista.obecnaPozycja = 5
//        } else if punkty >= 200 {
//            tenisista.obecnaPozycja = 6
//        } else if punkty >= 100 {
//            tenisista.obecnaPozycja = 7
//        }
//    }
//}
//
//func randking() {
//// Przykładowe użycie
//    let ranking = RankingTenisistow(tenisisci: [tenisista1, tenisista2, tenisista3]) // Dodaj odpowiednich tenisistów
//    ranking.wyswietlDaneTenisistow()
//
//// Przykład uaktualnienia wyników turnieju
//    let wynikiTurnieju = [("00011512345", 180), ("01234567890", 120), ("09876543210", 90)]
//    ranking.uaktualnijWynikiTurnieju(nazwaTurnieju: "US Open", wyniki: wynikiTurnieju)
//    ranking.wyswietlDaneTenisistow()
//}
//
//
