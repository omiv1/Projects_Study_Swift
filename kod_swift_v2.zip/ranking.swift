class RankingTenisistow {
    var tenisisci: [Tenisista]

    init(tenisisci: [Tenisista]) {
        self.tenisisci = tenisisci
    }

    func wyswietlDaneTenisistow() {
        for tenisista in tenisisci {
            tenisista.wyswietlDane()
            print("-----------------------------")
        }
    }

    func wyswietlSinglistow() {
        let singliści = tenisisci.filter { $0.rodzajGry == .single }
        for singlista in singliści {
            singlista.wyswietlDane()
            print("-----------------------------")
        }
    }

    func wyswietlNajwyzszaPozycje() {
        let posortowaniTenisisci = tenisisci.sorted { $0.obecnaPozycja < $1.obecnaPozycja }
        let najwyzszaPozycja = posortowaniTenisisci.first?.obecnaPozycja ?? 0

        let najlepsiTenisisci = tenisisci.filter { $0.obecnaPozycja == najwyzszaPozycja }
        for tenisista in najlepsiTenisisci {
            tenisista.wyswietlDane()
            print("-----------------------------")
        }
    }

    func znajdzTenisiste(pesel: String) -> Tenisista? {
        return tenisisci.first { $0.pesel == pesel }
    }

    func uaktualnijTurniej(pesel: String, nazwaTurnieju: String, punkty: Int) {
        if let tenisista = znajdzTenisiste(pesel: pesel) {
            tenisista.dodajTurniej(nazwa: nazwaTurnieju, punkty: punkty)
        }
    }

    func uaktualnijWynikiTurnieju(nazwaTurnieju: String, uczestnicy: [String], punkty: [Int]) {
        for i in 0..<uczestnicy.count {
            uaktualnijTurniej(pesel: uczestnicy[i], nazwaTurnieju: nazwaTurnieju, punkty: punkty[i])
        }

        // Uaktualnianie obecnej pozycji dla wszystkich tenisistów
        tenisisci.sort { $0.sumarycznaLiczbaPunktow > $1.sumarycznaLiczbaPunktow }
        for (index, tenisista) in tenisisci.enumerated() {
            tenisista.obecnaPozycja = index + 1
        }
    }
}
