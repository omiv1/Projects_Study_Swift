//
//  Display+CoreDataProperties.swift
//  iosProject_MOLO
//
//  Created by student on 11/06/2024.
//
//

import Foundation
import CoreData


extension Display {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Display> {
        return NSFetchRequest<Display>(entityName: "Display")
    }

    @NSManaged public var aspectRatioX: Int16
    @NSManaged public var aspectRatioY: Int16
    @NSManaged public var bezelSize: Double
    @NSManaged public var diagonal: Double
    @NSManaged public var type: Type?

}

extension Display : Identifiable {

}
