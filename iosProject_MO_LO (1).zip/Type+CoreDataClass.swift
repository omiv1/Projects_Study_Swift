import Foundation
import CoreData

@objc(Type)
public class Type: NSManagedObject {

}
