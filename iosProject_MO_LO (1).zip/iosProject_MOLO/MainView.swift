import SwiftUI

struct MainView: View {
    @FetchRequest(entity: Display.entity(), sortDescriptors: [])
    var displays: FetchedResults<Display>
    @Environment(\.managedObjectContext) private var viewContext
    @State private var selectedDisplays: [Display] = []
    @State private var comparisonMode: Bool = false
    @State private var editingDisplay: Display?

    var body: some View {
        NavigationView {
            VStack {
                Toggle("Overlay Comparison Mode", isOn: $comparisonMode)
                    .padding()

                List {
                    ForEach(displays) { display in
                        HStack {
                            getDisplayIcon(for: display.type?.name ?? "Unknown")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40)
                                .padding(.trailing, 10)
                            VStack(alignment: .leading) {
                                Text("\(display.diagonal, specifier: "%.1f") inches, \(display.aspectRatioX):\(display.aspectRatioY)")
                                    .font(.headline)
                                if let typeName = display.type?.name {
                                    Text(typeName)
                                        .padding(4)
                                        .background(Color.gray.opacity(0.2))
                                        .cornerRadius(4)
                                }
                            }
                            Spacer()
                            if selectedDisplays.contains(display) {
                                Image(systemName: "checkmark")
                            }
                        }
                        .onTapGesture {
                            if selectedDisplays.contains(display) {
                                selectedDisplays.removeAll { $0 == display }
                            } else {
                                selectedDisplays.append(display)
                            }
                        }
                        .swipeActions(edge: .leading) {
                            Button {
                                editingDisplay = display
                            } label: {
                                Label("Edit", systemImage: "pencil")
                            }
                            .tint(.blue)
                        }
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) {
                                deleteDisplay(display)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                }
                .navigationBarTitle("Displays")
                .navigationBarItems(trailing:
                    NavigationLink(destination: AddDisplayView()) {
                        Label("Add", systemImage: "plus")
                            .padding(10)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                )
                
                NavigationLink(destination: comparisonMode ? AnyView(OverlayComparisonView(displays: selectedDisplays)) : AnyView(ComparisonView(displays: selectedDisplays))) {
                    Text("Compare")
                        .padding()
                        .background(selectedDisplays.isEmpty ? Color.gray : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .disabled(selectedDisplays.isEmpty)
                .padding()
            }
        }
        .sheet(item: $editingDisplay) { display in
            AddDisplayView(displayToEdit: display)
        }
    }

    private func deleteDisplay(_ display: Display) {
        withAnimation {
            viewContext.delete(display)
            selectedDisplays.removeAll { $0 == display }
            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

    private func getDisplayIcon(for type: String) -> Image {
        switch type {
        case "Phone":
            return Image(systemName: "iphone")
        case "Television":
            return Image(systemName: "tv")
        case "Monitor":
            return Image(systemName: "desktopcomputer")
        default:
            return Image(systemName: "questionmark.circle")
        }
    }
}
