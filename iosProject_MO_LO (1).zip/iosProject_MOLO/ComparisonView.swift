import SwiftUI

struct ComparisonView: View {
    var displays: [Display]
    
    var body: some View {
        GeometryReader { geometry in
            let maxWidth = geometry.size.width - 40
            let maxHeight = geometry.size.height - 40
            let largestDisplay = displays.max(by: { $0.diagonal < $1.diagonal })!
            let largestAspectRatio = CGFloat(largestDisplay.aspectRatioX) / CGFloat(largestDisplay.aspectRatioY)
            let referenceWidth: CGFloat = min(maxWidth, maxHeight * largestAspectRatio)
            let referenceHeight: CGFloat = referenceWidth / largestAspectRatio

            ScrollView {
                VStack {
                    ForEach(displays, id: \.self) { display in
                        DisplayComparisonView(display: display, referenceWidth: referenceWidth, referenceHeight: referenceHeight, largestDisplay: largestDisplay)
                            .padding(.bottom, 20)
                    }
                }
                .padding()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .background(Color.white)
        }
        .navigationBarTitle("Comparison", displayMode: .inline)
    }
}

struct DisplayComparisonView: View {
    var display: Display
    var referenceWidth: CGFloat
    var referenceHeight: CGFloat
    var largestDisplay: Display

    var body: some View {
        let aspectRatio = CGFloat(display.aspectRatioX) / CGFloat(display.aspectRatioY)
        let scaleFactor = CGFloat(display.diagonal / largestDisplay.diagonal)
        let width = referenceWidth * scaleFactor
        let height = width / aspectRatio

        return VStack {
            Text("Display: \(display.diagonal, specifier: "%.1f") inches, \(display.aspectRatioX):\(display.aspectRatioY)")
            Rectangle()
                .fill(Color.gray)
                .frame(width: width, height: height)
                .overlay(
                    Rectangle()
                        .stroke(Color.black, lineWidth: display.bezelSize > 0 ? CGFloat(display.bezelSize) : 2)
                )
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}
