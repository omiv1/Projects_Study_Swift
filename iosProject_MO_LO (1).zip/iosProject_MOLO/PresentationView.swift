import SwiftUI

struct PresentationView: View {
    var displays: [Display]
    @State private var showBezel: Bool = true

    var body: some View {
        VStack {
            Toggle("Show Bezel", isOn: $showBezel)
                .padding()

            ForEach(displays, id: \.self) { display in
                DisplayView(display: display, showBezel: $showBezel)
                    .gesture(
                        MagnificationGesture()
                            .onChanged { value in
                            }
                            .simultaneously(with: RotationGesture()
                                .onChanged { value in
                                }
                            )
                    )
            }
        }
    }
}

struct DisplayView: View {
    var display: Display
    @Binding var showBezel: Bool

    var body: some View {
        Text("Display: \(display.diagonal) inches, \(display.aspectRatioX):\(display.aspectRatioY)")
    }
}
