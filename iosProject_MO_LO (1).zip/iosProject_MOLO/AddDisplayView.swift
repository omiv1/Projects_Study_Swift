import SwiftUI

struct AddDisplayView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) var presentationMode
    @FetchRequest(entity: Type.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Type.name, ascending: true)]) var types: FetchedResults<Type>
    @State private var selectedType: Type?
    @State private var diagonal: String = ""
    @State private var aspectRatioX: String = ""
    @State private var aspectRatioY: String = ""
    @State private var bezelSize: String = "1"
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    var displayToEdit: Display?

    var body: some View {
        Form {
            Section(header: Text("Display Details")) {
                TextField("Diagonal", text: $diagonal)
                    .keyboardType(.decimalPad)
                TextField("Aspect Ratio X", text: $aspectRatioX)
                    .keyboardType(.numberPad)
                TextField("Aspect Ratio Y", text: $aspectRatioY)
                    .keyboardType(.numberPad)
                TextField("Bezel Size", text: $bezelSize)
                    .keyboardType(.decimalPad)
                Picker("Type", selection: $selectedType) {
                    ForEach(types, id: \.self) { type in
                        Text(type.name ?? "Unknown").tag(type as Type?)
                    }
                }
                .pickerStyle(MenuPickerStyle())
            }

            Button(action: saveDisplay) {
                Text(displayToEdit == nil ? "Add Display" : "Save Changes")
            }
        }
        .navigationBarTitle(displayToEdit == nil ? "Add Display" : "Edit Display", displayMode: .inline)
        .onAppear {
            if let display = displayToEdit {
                diagonal = "\(display.diagonal)"
                aspectRatioX = "\(display.aspectRatioX)"
                aspectRatioY = "\(display.aspectRatioY)"
                bezelSize = "\(display.bezelSize)"
                selectedType = display.type
            } else {
                if let defaultType = types.first(where: { $0.name == "Monitor" }) {
                    selectedType = defaultType
                }
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Invalid Input"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }

    private func saveDisplay() {
        guard validateInput() else {
            return
        }

        let display: Display
        if let displayToEdit = displayToEdit {
            display = displayToEdit
        } else {
            display = Display(context: viewContext)
        }

        display.diagonal = Double(diagonal) ?? 0.0
        display.aspectRatioX = Int16(aspectRatioX) ?? 0
        display.aspectRatioY = Int16(aspectRatioY) ?? 0
        display.bezelSize = Double(bezelSize) ?? 1.0
        display.type = selectedType

        do {
            try viewContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            alertMessage = "Failed to save display. Please try again."
            showAlert = true
        }
    }

    private func validateInput() -> Bool {
        if Double(diagonal) == nil || Double(diagonal)! <= 0 {
            alertMessage = "Diagonal must be a positive decimal number."
            showAlert = true
            return false
        }

        if Int(aspectRatioX) == nil || Int(aspectRatioX)! <= 0 {
            alertMessage = "Aspect Ratio X must be a positive integer."
            showAlert = true
            return false
        }

        if Int(aspectRatioY) == nil || Int(aspectRatioY)! <= 0 {
            alertMessage = "Aspect Ratio Y must be a positive integer."
            showAlert = true
            return false
        }

        if Double(bezelSize) == nil || Double(bezelSize)! < 0 {
            alertMessage = "Bezel Size must be a non-negative decimal number."
            showAlert = true
            return false
        }

        if selectedType == nil {
            alertMessage = "Please select a type."
            showAlert = true
            return false
        }

        return true
    }
}
