import SwiftUI

struct OverlayComparisonView: View {
    var displays: [Display]
    @State private var scale: CGFloat = 1.0
    @State private var lastScaleValue: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        GeometryReader { geometry in
            let maxWidth = geometry.size.width - 40
            let maxHeight = geometry.size.height - 40
            
            let largestDisplay = displays.max(by: { $0.diagonal < $1.diagonal })!
            let aspectRatio = CGFloat(largestDisplay.aspectRatioX) / CGFloat(largestDisplay.aspectRatioY)
            let referenceWidth: CGFloat = min(maxWidth, maxHeight * aspectRatio)
            let referenceHeight: CGFloat = referenceWidth / aspectRatio

            ZStack {
                ForEach(displays, id: \.self) { display in
                    DisplayOverlayView(display: display, referenceWidth: referenceWidth, referenceHeight: referenceHeight, largestDisplay: largestDisplay)
                        .opacity(0.5)
                }
            }
            .scaleEffect(scale)
            .offset(x: offset.width, y: offset.height)
            .gesture(MagnificationGesture()
                .onChanged { value in
                    scale = lastScaleValue * value
                }
                .onEnded { value in
                    lastScaleValue = scale
                }
                .simultaneously(with: DragGesture()
                    .onChanged { value in
                        offset = CGSize(width: lastOffset.width + value.translation.width, height: lastOffset.height + value.translation.height)
                    }
                    .onEnded { value in
                        lastOffset = offset
                    }
                )
            )
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            .background(Color.white)
        }
        .navigationBarTitle("Overlay Comparison", displayMode: .inline)
    }
}

struct DisplayOverlayView: View {
    var display: Display
    var referenceWidth: CGFloat
    var referenceHeight: CGFloat
    var largestDisplay: Display

    var body: some View {
        let aspectRatio = CGFloat(display.aspectRatioX) / CGFloat(display.aspectRatioY)
        let scaleFactor = CGFloat(display.diagonal / largestDisplay.diagonal)
        let width = referenceWidth * scaleFactor
        let height = width / aspectRatio

        return Rectangle()
            .fill(Color.random)
            .frame(width: width, height: height)
            .overlay(
                Rectangle()
                    .stroke(Color.black, lineWidth: display.bezelSize > 0 ? CGFloat(display.bezelSize) : 2)
            )
            .position(x: width / 2, y: referenceHeight - height / 2)
    }
}

extension Color {
    static var random: Color {
        return Color(
            red: .random(in: 0...1),
            green: .random(in: 0...1),
            blue: .random(in: 0...1)
        )
    }
}
