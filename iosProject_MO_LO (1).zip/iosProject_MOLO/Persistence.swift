import CoreData

struct PersistenceController {
    static let shared = PersistenceController()

    let container: NSPersistentContainer

    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "iosProject_MOLO")
        if inMemory {
            container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores { description, error in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }

        let context = container.viewContext
        let fetchRequest: NSFetchRequest<Type> = Type.fetchRequest()
        fetchRequest.predicate = NSPredicate(value: true)

        do {
            let existingTypes = try context.fetch(fetchRequest)
            let typeNames = ["Phone", "Television", "Monitor"]
            var updatedTypes = [String: Type]()
            
            for typeName in typeNames {
                if let existingType = existingTypes.first(where: { $0.name == typeName }) {
                    updatedTypes[typeName] = existingType
                } else {
                    let newType = Type(context: context)
                    newType.name = typeName
                    updatedTypes[typeName] = newType
                }
            }

            for existingType in existingTypes {
                if !typeNames.contains(existingType.name ?? "") {
                    context.delete(existingType)
                }
            }

            try context.save()
        } catch {
            fatalError("Unresolved error \(error), \(error.localizedDescription)")
        }
    }
}
