//
//  Type+CoreDataProperties.swift
//  iosProject_MOLO
//
//  Created by student on 11/06/2024.
//
//

import Foundation
import CoreData


extension Type {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Type> {
        return NSFetchRequest<Type>(entityName: "Type")
    }

    @NSManaged public var name: String?
    @NSManaged public var displays: NSSet?

}

extension Type {

    @objc(addDisplaysObject:)
    @NSManaged public func addToDisplays(_ value: Display)

    @objc(removeDisplaysObject:)
    @NSManaged public func removeFromDisplays(_ value: Display)

    @objc(addDisplays:)
    @NSManaged public func addToDisplays(_ values: NSSet)

    @objc(removeDisplays:)
    @NSManaged public func removeFromDisplays(_ values: NSSet)

}

extension Type : Identifiable {

}
