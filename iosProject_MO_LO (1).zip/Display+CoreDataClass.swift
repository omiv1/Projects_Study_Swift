import Foundation
import CoreData

@objc(Display)
public class Display: NSManagedObject {

}
